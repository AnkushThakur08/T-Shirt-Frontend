import React from "react";
import Base from "../core/Base";

const UserDashBoard = () => {
  return (
    <Base title="UserDashBoard Profile">
      <h1>This is a UserDashBoard Page</h1>
    </Base>
  );
};

export default UserDashBoard;
