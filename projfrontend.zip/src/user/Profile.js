import React from "react";
import Base from "../core/Base";

const Profile = () => {
  return (
    <Base title="User Profile">
      <h1>This is a Profile Page</h1>
    </Base>
  );
};

export default Profile;
